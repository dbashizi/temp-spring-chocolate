package com.tiy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MakeChocolateSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(MakeChocolateSpringApplication.class, args);
	}
}
